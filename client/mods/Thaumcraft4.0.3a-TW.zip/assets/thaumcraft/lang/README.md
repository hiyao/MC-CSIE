Thaumcraft 4
============

Thaumcraft localization files

Add any localization files here to add language support for Thaumcraft 4

Always use the en_US.lang file as the origin of your entries, this is the most up-to-date file! 
Do not change en_US.lang! You can make pull requests for it if you find an error, but I will 
not merge them and update them by hand.

Keep in mind these files HAVE to be UTF-8 without BOM encoded, anything else will NOT work!

